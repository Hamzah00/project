README.txt

This is a web app for a haircut site that includes a booking feature and implementation for contacting barbers through email.
For the booking feature, to receive appropriate timeslots of a given date and post to google Calendar, HTTP requests are sent utilizing a free NodeJS Booking App, license availible within the lusciousWeb folder. We utilized Firebase as our database to hold all reservation information (reservation info + client's name, email, and phone). This information from our realtime database in Firebase was also used to implement code in which prevents double booking by removing reserved timeslots of a given date. All reservation information are also saved to the barber's google form as a response and they are given an email notification for each response.

Projects deliverables can be found in the project deliverables folder.

To run this application:

Step 1: Run the following command in your terminal:

npm install googleapis@39 -- save

Step 2: downlaod zip and cd into new zip file (lusciousWeb).
The required credentials is in the Utility folder

Enter the command to install required node packages:
npm install

Step 3: run the following command 
node .

Step 4: (If prompted) After running this command you might be prompted to Authorize the app by visiting a url given in terminal. Go to the url and sign in with your gmail account. 

Click allow/continue to get the code/token. Enter whatever code given into terminal then the server will connect.
