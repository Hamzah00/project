// FIREBASE
var database = firebase.database();
var detailsList = firebase.database().ref('details');
var detailsRef = firebase.database().ref('details/');

var selectDate = document.getElementById('selectDate');
var slots = document.getElementById('slots');
var resp = document.getElementById('response');
var resp1 = document.getElementById('response1');
var input = document.getElementById('input');
var selectTime = document.getElementById('selectTime');

var details = "";

// date variables
var year;
var month;
var day;
var date;

// time variables
var start;
var end;
var startHr;
var ogStartHr;
var startMin;

// Array of options to be included in drop down menu
var options = [];

// Array to keep track of appointments to avoid conflict
var appointments = [];

// HTTP REQUEST URLs
var getUrl;
var postUrl;

selectDate.addEventListener("click", userDate);
selectTime.addEventListener("click", confirmTime);


var dateStr = "";



// Collect user input of date and assign appropriate getUrl.
function userDate(){

	date = document.getElementById('date');
	date = JSON.stringify(date.value);

	year = date.substring(1, 5);

	month = date.substring(6, 8);

	day = date.substring(9, 11);

	dateStr = month + "/" + day + "/" + year;
	console.log("dateStr: " + dateStr); 



	getUrl = `http://localhost:8080/timeslots?year=${year}&month=${month}&day=${day}`;

	displaySlots();

} // [END: userDate]


// Show availible time slots of given date
function displaySlots(){
	fetch(getUrl)
	.then(response => response.json())
	.then(data => {

		input.innerHTML = "<option selected>Select an appointment time...</option>";
		document.getElementById("slotsHere").innerHTML = "";

		// Assign json response from GET request to timeslots 
		var timeslots = data['timeslots'];
		
		// Display All Info:
		// stringify data in timeslots
		// shows start time and end time
		var json_data = JSON.stringify(timeslots);

		// Handle invalid selected dates
		if (json_data == null){
			alert("Invalid date");
			// Display error to user
			resp.innerHTML = "<br> <p> There are no availble timeslots for the chosen date. </p> <p> Please select another day. <p>";
			document.getElementById("slotsHere").innerHTML = "";
		}
		// Otherwise show timeslots (of valid date)
		else{
			// // Display what date the user chose
			resp.innerHTML = `Availble timeslots for : ${month}/${day}/${year} `;

			// Take timeslots provided from get request and push to an result array
			var result = [];
			for(var i in timeslots){
				result.push([i, JSON.stringify(timeslots [i])]);
			}


			// Set up variables to pass to regularTime()
			for (var i = 0; i < result.length; i++) {
				var timeStr = result[i][1];

				// Get hour and minute value from string
				start = timeStr.substring(15,20);
				ogStartHr = start.substring(0,2);
				startHr = start.substring(0,2);
				startMin = start.substring(3,5);
				end = timeStr.substring(38,43);


				var endHr = end.substring(0,2);
				var endMin = end.substring(3,5);

				regularTime(startHr, endHr, start, end, startHr, startMin, endHr, endMin);

			}

		} // [END: else]


	})
.catch(err => alert("Invalid submission"));

} // [END: displaySlots]


// Display user friendly regular time 12hr time, instead of 24hr format
// Include AM and PM depending on time
function regularTime(startHr, endHr, start, end, startHr, startMin, endHr, endMin){


	var sHour = startHr - 17;
	var eHour = endHr - 17;
	var noon = 12;


	// Fix START hours
	// Special case = 12
	// leave startHr as is (17)
	if (sHour == 0){
		start = noon + ":" + startMin + "PM";
	}
	// Handle AM: sHour < 0 (gives negative)
	// EX: 14:00 -> 09:OOam
	else if (sHour < 0){
		startHr = startHr - 5;

		if (startHr < 10){
			startHr = "0" + startHr;
		}
		// 14 - 5 = 09
		start = startHr + ":" + startMin + "AM";
		// 09:00 AM
	// EX: 18:30 -> 1:30pm
	} else if (sHour > 0){
		startHr = startHr - 17;
		if (startHr < 10){
			startHr = "0" + startHr;
		}
		start = startHr + ":" + startMin + "PM";
	}

	// Fix END hours
	// Special case hour = 12
	if (eHour == 0){
		end = noon + ":" + endMin + "PM";
	}
	// Handle AM
	else if (eHour < 0){
		endHr = endHr - 5;
		if (endHr < 10){
			endHr = "0" + endHr;
		}
		// 14 - 5 = 09
		end = endHr + ":" + endMin + "AM";
		// 09:00 AM
	// EX: 18:30 -> 1:30pm
	} else if (eHour > 0){
		endHr = endHr - 17;
		if (endHr < 10){
			endHr = "0" + endHr;
		}
		end = endHr + ":" + endMin + "PM";
	}

	//  if starting hours of that date is not already taken
	console.log("Start " + start);
	var resStr = `${dateStr} at ${start}`;
	console.log("resStr " + resStr);

	// Avoid showing reservations that are already booked in available timeslots
	detailsList.orderByChild("appointment").equalTo(resStr).once("value",snapshot => {
		// if reservation already exists in DB
		if (snapshot.exists()){

			  const userData = snapshot.val();
			  console.log("Did not add reserved slot to options");
		}else{
			// add to options in the drop down menu if time is not reserved
			// Push new starting hours to options
			options.push([start]);

			// Display all time slots in new format 
			//document.getElementById("slotsHere").innerHTML += 
			//"<button>" + start + "-" + end + "</button>" + "<br> <br>";

			// Add adjusted time format to dropdown menu (start hr only)
			input.innerHTML +=  " <option value=" + start + ">" + start +"</option>     "; 
		} // [END: else]

	});


} // [END: regularTime]


function confirmTime(){

	// Var from user input of selected time
	console.log ("Input " + input.value);
	var newMin = input.value.substring(3,5);
	var twelveHr = input.value.substring(0,2);
	var substr = input.value.substring(0,2);
	var newHour = input.value.substring(0,2);
	var firstDigit = input.value.substring(0,1);
	var secDigit = input.value.substring(2,2);

	var period = "PM";

	if (newHour == "09" || newHour == "10" || newHour == "11"){
		period = "AM";
	}

	// Avoid user error of not selecting a valid time
	if (input.value == 'Select an appointment time...'){
        alert("Please select a valid option.");
    }
    else{
    	// newHour keeps track of 24hr format for HTTP requests

    	if(firstDigit == "0"){
    		if (substr.includes("09")){
    			newHour = 14;
    		}
    		else if (substr.includes("01")){
    			newHour = 18;
    		}
    		else if (substr.includes("01")){
    			newHour = 19;
    		}
    		else if (substr.includes("01")){
    			newHour = 20;
    		}
    		else if (substr.includes("04")){
    			newHour = 21;
    		}
    	} else {
    		if (substr.includes("10")){
    			newHour = 15;
    		}
    		if (substr.includes("11")){
    			newHour = 16;
    		}
    		if (substr.includes("12")){
    			newHour = 17;
    		}
    	}


    	// **** Implemntation of avoid conflict times

    	// Appointment details in user friendly format
    	details = month + "/" + day + "/" + year + " at " + twelveHr + ":" + newMin + period;
    	
    	// Debugging purposes
    	console.log("Details: " + details);


    	// CHECK if in DB, if it is NOT add to DB
    	detailsList.orderByChild("appointment").equalTo(details).once("value",snapshot => {
    		// if details already exists in DB
		    if (snapshot.exists()){
			      const userData = snapshot.val();
			      console.log("VALUES " + userData);
			      console.log("exists!", userData);
			      console.log("Cant book appointment. It's taken.");
			}else{
				if (details != ""){
					// add details to DB since its not already in there
					var newdetail = detailsList.push();
					newdetail.set({
						// ...
						appointment: details
					});
					// Since time is available, POST request allowed
					// POST request url to post the selected timeslot in google calendar
					postUrl = `http://localhost:8080/book?year=${year}&month=${month}&day=${day}&hour=${newHour}&minute=${newMin}`;

					// Save to local storage to be able to use vars in confirm.js
					localStorage.setItem("appointmentInfo",details);
					localStorage.setItem("postUrl", postUrl);
					console.log("Congrats. Booked.");
					// Redirect user to new page
					parent.location = 'confirm.html';
				}
				
			}
		});

    }
} // [END: confirmTime]















