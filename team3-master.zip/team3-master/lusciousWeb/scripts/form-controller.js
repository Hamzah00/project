var info = localStorage.getItem("appointmentInfo");
//Initializes all controllers
const initControllers = function(){
	const bookButton = document.getElementById('book');
	bookButton.addEventListener('click', submitEvent);
}
//Submit event -- set HTTP attributes for the reservations form
const submitEvent = function(){
	const formData = new Object();
	formData[entry1] = document.getElementById('name').value;
	formData[entry2] = document.getElementById('email').value;
	formData[entry3] = document.getElementById('phone').value;
	formData[entry4] = info;

	postToGoogleDB(formData);
}

initControllers();   //Must be last line of code