// FIREBASE
var database = firebase.database();
var appointmentRef = firebase.database().ref("appointments/");
// Get vars from app.js using localStorage
var info = localStorage.getItem("appointmentInfo");
var postUrl = localStorage.getItem("postUrl");

// getElementById vars
var showAp = document.getElementById('showAp');
var userName = document.getElementById('name');
var email = document.getElementById('email');
var phone = document.getElementById('phone');

var bookButton = document.getElementById('book');
bookButton.addEventListener("click", confirmBooking);


// Display appointment details user selected
window.onload = function () {
    showAp.innerHTML = "<p> Please confirm your appointment of " + info + " by submitting the following information.</p>";
}

// Invoked with Booked Appointment button
function confirmBooking(){

    userName = userName.value;
    email = email.value;
    phone = phone.value;

    // Write to DB
    var apInfo = appointmentRef.push();
				apInfo.set({
				    name : userName,
                    email : email,
                    phone : phone,
                    reservation : info
				});

    // Set up fetch for POST request to post to calendar
    console.log(postUrl);
	const param = {
	    year: year
	};
	fetch(postUrl, {
		method: 'POST',
        body: JSON.stringify(param),
        headers: {
            'Content-type': 'application/json; charset=UTF-8'
        }
    })
    .then(response => response.json())
    .then(json => {
        console.log(json);
    });

    alert("Your appointment is scheduled for " + info);

} // [END: confirmBooking]

