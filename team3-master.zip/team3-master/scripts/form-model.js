const formId = "1FAIpQLScIUA7WYqef9DU94IcrVOihfPl22k8N8nEQZij32M9dhxE2ew";
// first and last name
const entry1 = "entry.1483386956";
// email
const entry2 = "entry.2054159992";
// phone number 
const entry3 = "entry.1576205281";



// date mm/dd/yyyy
const entry4 = "entry.525395183";
// time hh:min AM/PM
const entry5 = "entry.1276645843";



const getPath = formId => `https://docs.google.com/forms/d/e/${formId}/formResponse`;

const postToGoogleDB = function( data ){
	const path = getPath ( formId );
	const url = getURL ( path, data );
	sendRequest ( 'POST', url ).then(responseEvent);
}

const getURL = function ( path, params ){
	const url = new URL(path);
	for( let key in params ){
		url.searchParams.set(key, params [key] );
	}
	return url;
}

const sendRequest = async function(verb, url) {
	const request = initRequest(verb, url);
	const response = await fetch(request);
	return response;
}

const initRequest = function (verb, url){
	const init = new Object();
	init.method = verb;
	init.mode = "no-cors";
	return new Request(url, init);
}


const responseEvent = response => alert('Success!');
